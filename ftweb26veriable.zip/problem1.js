
let x="Masai School";
let y="A Transformation in Education"
console.log(x)
console.log(y)
