let x="Raunak";
console.log(x)
let y="Rajesh"
console.log(y)
let z="Sarita"
console.log(z)