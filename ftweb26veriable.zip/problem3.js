let a="Raunak"
let b=25
console.log(a,b)
console.log(typeof(a))
console.log(typeof(b))