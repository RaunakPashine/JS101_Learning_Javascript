let name ="Raunak";
let school="J.M. patel college Bhandara";
let gread="A gread";
let section= "B section";
let rollno=1623;
let m1=99
m2=98
m3=95
console.log(name)
console.log(school)
console.log(gread)
console.log(section)
console.log(rollno)
console.log(m1)
console.log(m2)
console.log(m3)
