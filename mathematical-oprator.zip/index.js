let a=3;
let b=2;
console.log("sum is",a+b)
console.log("sub is",a-b)
console.log("mul is",a*b)
console.log("div is",a/b)
console.log("mod is",a%b)
console.log(a**b)